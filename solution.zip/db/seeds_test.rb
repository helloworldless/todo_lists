require_relative 'seeds.rb'

puts @candidates